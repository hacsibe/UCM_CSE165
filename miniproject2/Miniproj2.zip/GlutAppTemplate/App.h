#ifndef App_hpp
#define App_hpp
#include "Rect.h"
#include "Vec.h"
#include<vector>
#include "GlutApp.h"

using namespace std;
class App: public GlutApp {
    // Maintain app state here
    float mx;
    float my;

    //Rect rectangles(-0.5f,0.3f,-0.2f,-0.5f);
    //Rect rectangles(0.5f,-0.4f,0.1f, 0.1f);
    //Rect* rect_1 = &rectangles;
    //Rect* rect_2 = &rectangles;
    std::vector<Rect> rectangle;
public:
    // Constructor, to initialize state
    App(const char* label, int x, int y, int w, int h);
    
    // These are the events we want to handle
    void draw();
    void keyPress(unsigned char key);
    void mouseDown(float x, float y);
    void mouseDrag(float x, float y);
};

#endif
